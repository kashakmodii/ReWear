import React, { useState } from "react";
import axios from "axios";
import SellerDashboard from "./SellerDashboard";

export default function BecomeSeller() {
  const [step, setStep] = useState(1);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [mobile, setMobile] = useState("");
  const [gstin, setGstin] = useState("");
  const [category, setCategory] = useState("all");
  const [password, setPassword] = useState("");
  const [confirmPass, setConfirmPass] = useState("");
  const [isRegistered, setIsRegistered] = useState(false);

  const nextStep = () => setStep(step + 1);
  const prevStep = () => setStep(step - 1);

  const handleRegister = async (e) => {
    e.preventDefault();
    if (password !== confirmPass) {
      alert("Passwords do not match!");
      return;
    }

    try {
      const response = await axios.post("http://localhost:5000/api/seller/register", {
        name: { first: firstName, last: lastName },
        email,
        mobile,
        gstin,
        category,
        password,
      });

      if (response.data.success) {
        alert("Seller registered successfully!");
        setIsRegistered(true);
      }
    } catch (err) {
      alert(err.response?.data?.message || "Registration failed");
    }
  };

  if (isRegistered) return <SellerDashboard />;

  return (
    <div className="min-h-screen flex justify-center items-center bg-gray-100">
      <div className="bg-white shadow-xl rounded-xl p-8 w-full max-w-md">
        {step === 1 && (
          <form onSubmit={(e) => { e.preventDefault(); nextStep(); }}>
            <input type="text" placeholder="First Name" value={firstName} onChange={(e) => setFirstName(e.target.value)} required />
            <input type="text" placeholder="Last Name" value={lastName} onChange={(e) => setLastName(e.target.value)} />
            <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            <input type="text" placeholder="Mobile" value={mobile} onChange={(e) => setMobile(e.target.value)} required />
            <input type="text" placeholder="GSTIN" value={gstin} onChange={(e) => setGstin(e.target.value)} />
            <button type="submit">Next →</button>
          </form>
        )}
        {step === 2 && (
          <form onSubmit={handleRegister}>
            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            <input type="password" placeholder="Confirm Password" value={confirmPass} onChange={(e) => setConfirmPass(e.target.value)} required />
            <button type="button" onClick={prevStep}>← Back</button>
            <button type="submit">Register →</button>
          </form>
        )}
      </div>
    </div>
  );
}
