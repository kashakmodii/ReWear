// backend/controllers/swapController.js
const Order = require('../models/Order');
const Item = require('../models/Item');
const User = require('../models/User');

exports.requestSwap = async (req, res) => {
  try {
    const { itemId, type } = req.body; // type = 'swap' or 'redeem'
    const item = await Item.findById(itemId);
    if (!item) return res.status(404).json({ message: 'Item not found' });
    if (type === 'redeem') {
      // check points
      if (req.user.points < (item.pointsRequired || 0)) return res.status(400).json({ message: 'Not enough points' });
      // deduct points and mark redeemed
      req.user.points -= (item.pointsRequired || 0);
      await req.user.save();
      item.status = 'redeemed';
      item.redeemedBy = req.user._id;
      await item.save();
      const order = await Order.create({ item: item._id, requester: req.user._id, owner: item.owner, type: 'redeem', status: 'completed' });
      return res.json({ order, message: 'Redeemed successfully' });
    } else {
      // swap request
      const order = await Order.create({ item: item._id, requester: req.user._id, owner: item.owner, type: 'swap', status: 'requested' });
      return res.json({ order, message: 'Swap requested' });
    }
  } catch (err) { res.status(500).json({ message: err.message }); }
};

exports.acceptSwap = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id).populate('item requester owner');
    if (!order) return res.status(404).json({ message: 'Order not found' });
    // only owner can accept
    if (String(order.owner._id) !== String(req.user._id)) return res.status(403).json({ message: 'Only owner can accept' });
    order.status = 'accepted';
    await order.save();
    // mark item as ongoing
    const item = await Item.findById(order.item._id);
    item.status = 'approved'; // still available until completed, or set different
    await item.save();
    res.json({ order });
  } catch (err) { res.status(500).json({ message: err.message }); }
};

exports.completeSwap = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'Order not found' });
    // either participant can mark complete; validate as needed
    order.status = 'completed';
    await order.save();
    const item = await Item.findById(order.item);
    item.status = 'redeemed';
    item.redeemedBy = order.requester;
    await item.save();
    // Optionally award points to owner/requester
    res.json({ order });
  } catch (err) { res.status(500).json({ message: err.message }); }
};
