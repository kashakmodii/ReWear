// backend/controllers/itemController.js
const Item = require('../models/Item');

exports.addItem = async (req, res) => {
  try {
    const { title, description, category, type, size, condition, tags, pointsRequired } = req.body;
    const images = (req.files || []).map(f => `/uploads/${f.filename}`);
    const item = await Item.create({
      owner: req.user._id,
      title, description, category, type, size, condition,
      tags: tags ? (Array.isArray(tags) ? tags : tags.split(',').map(t => t.trim())) : [],
      images,
      pointsRequired: pointsRequired ? Number(pointsRequired) : 0,
      status: 'pending'
    });
    return res.json({ item });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

exports.getApprovedItems = async (req, res) => {
  const q = {};
  if (req.query.category) q.category = req.query.category;
  q.status = 'approved';
  const items = await Item.find(q).populate('owner', 'name email');
  res.json(items);
};

exports.getItem = async (req, res) => {
  const item = await Item.findById(req.params.id).populate('owner','name email points');
  if (!item) return res.status(404).json({ message: 'Item not found' });
  res.json(item);
};

exports.deleteItem = async (req, res) => {
  const item = await Item.findById(req.params.id);
  if (!item) return res.status(404).json({ message: 'Item not found' });
  if (req.user.role !== 'admin' && String(item.owner) !== String(req.user._id)) {
    return res.status(403).json({ message: 'Not allowed' });
  }
  await item.remove();
  res.json({ message: 'Item removed' });
};

exports.pendingItems = async (req, res) => {
  const items = await Item.find({ status: 'pending' }).populate('owner', 'name email');
  res.json(items);
};

exports.approveItem = async (req, res) => {
  const item = await Item.findById(req.params.id);
  if (!item) return res.status(404).json({ message: 'Item not found' });
  item.status = req.body.status === 'rejected' ? 'rejected' : 'approved';
  await item.save();
  res.json({ item });
};
