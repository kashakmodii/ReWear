// MongoDB Collection Setup Script
// Run this script to create the users collection with proper validation

const { MongoClient } = require('mongodb');

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/your-database-name';

async function setupUserCollection() {
  const client = new MongoClient(MONGODB_URI);
  
  try {
    await client.connect();
    console.log('Connected to MongoDB');
    
    const db = client.db();
    
    // Create users collection with validation
    await db.createCollection("users", {
      validator: {
        $jsonSchema: {
          bsonType: "object",
          required: ["email", "password", "name"],
          properties: {
            name: {
              bsonType: "object",
              required: ["first", "last"],
              properties: {
                first: { 
                  bsonType: "string",
                  minLength: 1,
                  maxLength: 50
                },
                last: { 
                  bsonType: "string",
                  minLength: 1,
                  maxLength: 50
                }
              }
            },
            email: { 
              bsonType: "string", 
              pattern: "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",
              description: "unique user email" 
            },
            password: { 
              bsonType: "string", 
              minLength: 6,
              description: "bcrypt hashed password" 
            },
            phone: {
              bsonType: "object",
              properties: {
                countryCode: { 
                  bsonType: "string",
                  pattern: "^\\+[1-9]\\d{1,3}$"
                },
                number: { 
                  bsonType: "string",
                  pattern: "^[0-9]{10,15}$"
                }
              }
            },
            profilePicture: { 
              bsonType: "string",
              pattern: "^https?://.*"
            },
            points: { 
              bsonType: "int",
              minimum: 0,
              default: 0
            },
            wishlist: { 
              bsonType: "array",
              items: {
                bsonType: "object",
                required: ["productId", "addedAt"],
                properties: {
                  productId: {
                    bsonType: "objectId"
                  },
                  addedAt: {
                    bsonType: "date"
                  }
                }
              }
            },
            cart: { 
              bsonType: "array",
              items: {
                bsonType: "object",
                required: ["productId", "quantity", "addedAt"],
                properties: {
                  productId: {
                    bsonType: "objectId"
                  },
                  quantity: {
                    bsonType: "int",
                    minimum: 1
                  },
                  addedAt: {
                    bsonType: "date"
                  }
                }
              }
            },
            addresses: { 
              bsonType: "array",
              items: {
                bsonType: "object",
                required: ["type", "street", "city", "state", "zipCode"],
                properties: {
                  type: {
                    bsonType: "string",
                    enum: ["home", "work", "other"]
                  },
                  street: { bsonType: "string" },
                  city: { bsonType: "string" },
                  state: { bsonType: "string" },
                  zipCode: { bsonType: "string" },
                  country: { 
                    bsonType: "string",
                    default: "India"
                  },
                  isDefault: { 
                    bsonType: "bool",
                    default: false
                  }
                }
              }
            },
            purchases: { 
              bsonType: "array",
              items: {
                bsonType: "object",
                required: ["productId", "quantity", "price", "purchaseDate", "status"],
                properties: {
                  orderId: {
                    bsonType: "objectId"
                  },
                  productId: {
                    bsonType: "objectId"
                  },
                  quantity: {
                    bsonType: "int",
                    minimum: 1
                  },
                  price: {
                    bsonType: "number",
                    minimum: 0
                  },
                  purchaseDate: {
                    bsonType: "date"
                  },
                  status: {
                    bsonType: "string",
                    enum: ["pending", "shipped", "delivered", "cancelled"]
                  }
                }
              }
            },
            isActive: {
              bsonType: "bool",
              default: true
            },
            createdAt: {
              bsonType: "date"
            },
            updatedAt: {
              bsonType: "date"
            }
          }
        }
      }
    });
    
    // Create indexes for better performance
    await db.collection("users").createIndex({ email: 1 }, { unique: true });
    await db.collection("users").createIndex({ "wishlist.productId": 1 });
    await db.collection("users").createIndex({ "cart.productId": 1 });
    await db.collection("users").createIndex({ "purchases.productId": 1 });
    await db.collection("users").createIndex({ "purchases.orderId": 1 });
    
    console.log('✅ Users collection created successfully with validation and indexes');
    console.log('📋 Collection includes:');
    console.log('   - User profile information (name, email, phone)');
    console.log('   - Wishlist array with product references');
    console.log('   - Cart array with quantities');
    console.log('   - Addresses array for multiple addresses');
    console.log('   - Purchases array for order history');
    console.log('   - Points system for rewards');
    console.log('   - Proper validation and indexes');
    
  } catch (error) {
    console.error('❌ Error setting up collection:', error);
  } finally {
    await client.close();
  }
}

// Run the setup
setupUserCollection();


