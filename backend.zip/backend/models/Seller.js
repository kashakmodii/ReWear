import mongoose from 'mongoose';

const sellerSchema = new mongoose.Schema({
  name: {
    first: { type: String, required: true },
    last: { type: String, default: "" }
  },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  mobile: { 
    type: String, 
    required: true, 
    match: [/^\d{10}$/, 'Please enter a valid 10-digit mobile number']
  },
  gstin: { 
    type: String, 
    match: [/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/, 'Please enter a valid GSTIN'], 
    default: ""
  },
  category: { type: String, default: "all" },
  password: { type: String, required: true, minlength: 6 },
  createdAt: { type: Date, default: Date.now }
});

// Hash password before saving
sellerSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const bcrypt = await import('bcryptjs');
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Compare password method
sellerSchema.methods.comparePassword = async function(candidatePassword) {
  const bcrypt = await import('bcryptjs');
  return bcrypt.compare(candidatePassword, this.password);
};

// Remove password from JSON output
sellerSchema.methods.toJSON = function() {
  const sellerObject = this.toObject();
  delete sellerObject.password;
  return sellerObject;
};

// Virtual for full name
sellerSchema.virtual('fullName').get(function() {
  return `${this.name.first} ${this.name.last}`.trim();
});

export default mongoose.model("sellers", sellerSchema);