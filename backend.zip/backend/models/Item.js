// backend/models/Item.js
const mongoose = require('mongoose');

const itemSchema = new mongoose.Schema({
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true },
  description: String,
  category: String,
  type: String,
  size: String,
  condition: String,
  tags: [String],
  images: [String], // urls or local paths like /uploads/xxx
  status: { type: String, enum: ['pending','approved','rejected','redeemed'], default: 'pending' },
  pointsRequired: { type: Number, default: 0 }, // if redeemable via points
  redeemedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null }
}, { timestamps: true });

module.exports = mongoose.model('Item', itemSchema);
