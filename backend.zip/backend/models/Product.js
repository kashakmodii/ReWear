import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
  sellerId: { type: mongoose.Schema.Types.ObjectId, ref: 'sellers', required: true },
  title: { type: String, required: true },
  description: { type: String, required: true },
  category: { 
    type: String, 
    required: true,
    enum: ['clothing', 'footwear', 'bags', 'jewelry', 'accessories', 'watches', 'eyewear', 'electronics', 'home', 'beauty', 'sports']
  },
  subcategory: { type: String, required: true },
  price: { type: Number, required: true, min: 1 },
  originalPrice: { type: Number },
  discount: { type: Number, default: 0, min: 0, max: 100 },
  size: { type: String, required: true },
  color: { type: String, required: true },
  condition: { 
    type: String, 
    required: true,
    enum: ['new', 'like-new', 'good', 'fair']
  },
  material: { type: String, default: "" },
  gender: { 
    type: String, 
    enum: ['men', 'women', 'unisex', 'kids'],
    default: 'unisex'
  },
  images: [{ 
    url: { type: String, required: true },
    isPrimary: { type: Boolean, default: false }
  }],
  stock: { type: Number, required: true, min: 0, default: 1 },
  status: { 
    type: String, 
    enum: ['active', 'inactive', 'out-of-stock'],
    default: 'active'
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Update updatedAt field before saving
productSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

export default mongoose.model("products", productSchema);


