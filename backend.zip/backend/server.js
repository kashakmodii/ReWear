// server.js
import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import sellerRoutes from './routes/sellerRoutes.js';
import userRoutes from './routes/userRoutes.js';
import Seller from './models/Seller.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: "key.env" });

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || "mysecretkey";

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Ensure upload directories exist
const uploadsDir = path.join(__dirname, 'uploads');
const profilesDir = path.join(__dirname, 'uploads', 'profiles');
const productsDir = path.join(__dirname, 'uploads', 'products');

if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}
if (!fs.existsSync(profilesDir)) {
  fs.mkdirSync(profilesDir, { recursive: true });
}
if (!fs.existsSync(productsDir)) {
  fs.mkdirSync(productsDir, { recursive: true });
}

// Serve static files from uploads directory
app.use('/uploads', express.static('uploads'));

// Configure multer for profile picture uploads
const profileStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, 'uploads', 'profiles'));
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'profile-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const profileUpload = multer({
  storage: profileStorage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only PNG and JPG files are allowed!'), false);
    }
  }
});

// Connect MongoDB
mongoose.connect("mongodb://localhost:27017/ReWearDB")
  .then(() => console.log("MongoDB Connected"))
  .catch(err => console.error("DB Error:", err));

// -------- USER SCHEMA & MODEL --------
const userSchema = new mongoose.Schema({
  name: {
    first: { type: String, required: true },
    last: { type: String, default: "" }
  },
  email: { type: String, unique: true, required: true },
  password: { type: String, required: true },
  phone: {
    countryCode: { type: String, default: "+91" },
    number: { type: String, default: "" }
  },
  profilePicture: { type: String, default: "" },
  points: { type: Number, default: 0 },
  wishlist: [{
    productId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'products'
    },
    addedAt: {
      type: Date,
      default: Date.now
    }
  }],
  cart: [{
    productId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'products'
    },
    quantity: {
      type: Number,
      default: 1,
      min: 1
    },
    addedAt: {
      type: Date,
      default: Date.now
    }
  }],
  addresses: [{
    type: {
      type: String,
      enum: ['home', 'work', 'other'],
      default: 'home'
    },
    street: String,
    city: String,
    state: String,
    zipCode: String,
    country: {
      type: String,
      default: 'India'
    },
    isDefault: {
      type: Boolean,
      default: false
    }
  }],
  purchases: [{
    orderId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'orders'
    },
    productId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'products'
    },
    quantity: Number,
    price: Number,
    purchaseDate: {
      type: Date,
      default: Date.now
    },
    status: {
      type: String,
      enum: ['pending', 'shipped', 'delivered', 'cancelled'],
      default: 'pending'
    }
  }],
  isActive: {
    type: Boolean,
    default: true
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Update updatedAt field before saving
userSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

const User = mongoose.model("users", userSchema);


// -------- USER ROUTES --------
app.post("/api/signup", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) return res.status(400).json({ message: "Name, email and password are required" });

    const parts = name.trim().split(/\s+/);
    const nameObj = { first: parts[0], last: parts.slice(1).join(" ") || "" };

    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ message: "User already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ 
      name: nameObj, 
      email, 
      password: hashedPassword,
      wishlist: [],
      cart: [],
      addresses: [],
      purchases: [],
      points: 0
    });
    await newUser.save();

    res.status(201).json({ message: "Account created successfully" });
  } catch (err) {
    console.error("Signup Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Login
app.post("/api/login", async (req, res) => {
  try {
    console.log('Login endpoint called');
    const { email, password } = req.body;
    console.log('Login attempt for email:', email);
    
    if (!email || !password) return res.status(400).json({ message: "Email and password are required" });

    const user = await User.findOne({ email });
    console.log('User found:', !!user);
    
    if (!user) return res.status(400).json({ message: "Invalid credentials" });

    const isMatch = await bcrypt.compare(password, user.password);
    console.log('Password match:', isMatch);
    
    if (!isMatch) return res.status(400).json({ message: "Invalid credentials" });

    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: "7d" });
    console.log('Token generated for user:', user._id);

    res.json({
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        profilePicture: user.profilePicture,
        points: user.points,
        wishlist: user.wishlist,
        cart: user.cart,
        addresses: user.addresses,
        purchases: user.purchases
      }
    });
  } catch (err) {
    console.error("Login Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Get user profile (protected route)
app.get("/api/profile", async (req, res) => {
  try {
    console.log('Profile endpoint called');
    const token = req.header('Authorization')?.replace('Bearer ', '');
    console.log('Token received:', !!token);
    
    if (!token) {
      console.log('No token provided');
      return res.status(401).json({ message: 'No token provided' });
    }

    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET);
      console.log('Token decoded, user ID:', decoded.id);
    } catch (jwtError) {
      console.error('JWT verification error:', jwtError);
      return res.status(401).json({ message: 'Invalid or expired token' });
    }
    
    const user = await User.findById(decoded.id);
    console.log('User found:', !!user);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    console.log('Returning user data');
    res.json({
      success: true,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        profilePicture: user.profilePicture,
        points: user.points,
        wishlist: user.wishlist,
        cart: user.cart,
        addresses: user.addresses,
        purchases: user.purchases
      }
    });
  } catch (err) {
    console.error("Get Profile Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Upload profile picture (protected route)
app.post("/api/profile/upload-picture", profileUpload.single('profilePicture'), async (req, res) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const profilePictureUrl = `/uploads/profiles/${req.file.filename}`;

    const user = await User.findByIdAndUpdate(
      decoded.id,
      { profilePicture: profilePictureUrl },
      { new: true }
    );
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      success: true,
      message: "Profile picture uploaded successfully",
      profilePicture: profilePictureUrl,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        profilePicture: user.profilePicture,
        points: user.points,
        wishlist: user.wishlist,
        cart: user.cart,
        addresses: user.addresses,
        purchases: user.purchases
      }
    });
  } catch (err) {
    console.error("Upload Profile Picture Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Change password (protected route)
app.post("/api/profile/change-password", async (req, res) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ message: 'Current password and new password are required' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ message: 'New password must be at least 6 characters' });
    }

    const user = await User.findById(decoded.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const isMatch = await bcrypt.compare(currentPassword, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Current password is incorrect' });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    await user.save();

    res.json({
      success: true,
      message: "Password changed successfully"
    });
  } catch (err) {
    console.error("Change Password Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Update user profile (protected route)
app.put("/api/profile", async (req, res) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const { firstName, lastName, phoneNumber, countryCode, profilePicture } = req.body;

    const updateData = {};
    if (firstName || lastName) {
      updateData.name = {};
      if (firstName) updateData.name.first = firstName;
      if (lastName) updateData.name.last = lastName;
    }
    if (phoneNumber !== undefined || countryCode !== undefined) {
      updateData.phone = {};
      if (phoneNumber !== undefined) updateData.phone.number = phoneNumber;
      if (countryCode !== undefined) updateData.phone.countryCode = countryCode;
    }
    if (profilePicture !== undefined) updateData.profilePicture = profilePicture;

    const user = await User.findByIdAndUpdate(decoded.id, updateData, { new: true });
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      success: true,
      message: "Profile updated successfully",
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        profilePicture: user.profilePicture,
        points: user.points,
        wishlist: user.wishlist,
        cart: user.cart,
        addresses: user.addresses,
        purchases: user.purchases
      }
    });
  } catch (err) {
    console.error("Update Profile Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// -------- WISHLIST & CART ENDPOINTS --------

// Get user's wishlist
app.get("/api/wishlist", async (req, res) => {
  try {
    console.log('Wishlist endpoint called');
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(decoded.id).populate('wishlist.productId');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      success: true,
      wishlist: user.wishlist
    });
  } catch (err) {
    console.error("Get Wishlist Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Add to wishlist
app.post("/api/wishlist", async (req, res) => {
  try {
    console.log('Add to wishlist endpoint called');
    const token = req.header('Authorization')?.replace('Bearer ', '');
    const { productId } = req.body;
    
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    if (!productId) {
      return res.status(400).json({ message: 'Product ID is required' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(decoded.id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if product already in wishlist
    const existingItem = user.wishlist.find(item => item.productId.toString() === productId);
    if (existingItem) {
      return res.status(400).json({ message: 'Product already in wishlist' });
    }

    user.wishlist.push({ productId });
    await user.save();

    res.json({
      success: true,
      message: 'Product added to wishlist',
      wishlist: user.wishlist
    });
  } catch (err) {
    console.error("Add to Wishlist Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Remove from wishlist
app.delete("/api/wishlist/:productId", async (req, res) => {
  try {
    console.log('Remove from wishlist endpoint called');
    const token = req.header('Authorization')?.replace('Bearer ', '');
    const { productId } = req.params;
    
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(decoded.id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.wishlist = user.wishlist.filter(item => item.productId.toString() !== productId);
    await user.save();

    res.json({
      success: true,
      message: 'Product removed from wishlist',
      wishlist: user.wishlist
    });
  } catch (err) {
    console.error("Remove from Wishlist Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Get user's cart
app.get("/api/cart", async (req, res) => {
  try {
    console.log('Cart endpoint called');
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(decoded.id).populate('cart.productId');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      success: true,
      cart: user.cart
    });
  } catch (err) {
    console.error("Get Cart Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Add to cart
app.post("/api/cart", async (req, res) => {
  try {
    console.log('Add to cart endpoint called');
    const token = req.header('Authorization')?.replace('Bearer ', '');
    const { productId, quantity = 1 } = req.body;
    
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    if (!productId) {
      return res.status(400).json({ message: 'Product ID is required' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(decoded.id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if product already in cart
    const existingItem = user.cart.find(item => item.productId.toString() === productId);
    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      user.cart.push({ productId, quantity });
    }

    await user.save();

    res.json({
      success: true,
      message: 'Product added to cart',
      cart: user.cart
    });
  } catch (err) {
    console.error("Add to Cart Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Update cart quantity
app.put("/api/cart/:productId", async (req, res) => {
  try {
    console.log('Update cart quantity endpoint called');
    const token = req.header('Authorization')?.replace('Bearer ', '');
    const { productId } = req.params;
    const { quantity } = req.body;
    
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(decoded.id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const cartItem = user.cart.find(item => item.productId.toString() === productId);
    if (!cartItem) {
      return res.status(404).json({ message: 'Product not found in cart' });
    }

    if (quantity <= 0) {
      user.cart = user.cart.filter(item => item.productId.toString() !== productId);
    } else {
      cartItem.quantity = quantity;
    }

    await user.save();

    res.json({
      success: true,
      message: 'Cart updated',
      cart: user.cart
    });
  } catch (err) {
    console.error("Update Cart Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Remove from cart
app.delete("/api/cart/:productId", async (req, res) => {
  try {
    console.log('Remove from cart endpoint called');
    const token = req.header('Authorization')?.replace('Bearer ', '');
    const { productId } = req.params;
    
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(decoded.id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.cart = user.cart.filter(item => item.productId.toString() !== productId);
    await user.save();

    res.json({
      success: true,
      message: 'Product removed from cart',
      cart: user.cart
    });
  } catch (err) {
    console.error("Remove from Cart Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// -------- API ROUTES --------
app.use('/api/seller', sellerRoutes);
app.use('/api/user', userRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'ReWear API is running',
    timestamp: new Date().toISOString()
  });
});

// Start server
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
