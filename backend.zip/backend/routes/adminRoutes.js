// backend/routes/adminRoutes.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const admin = require('../middleware/adminMiddleware');
const Item = require('../models/Item');

router.get('/items/pending', auth, admin, async (req, res) => {
  const items = await Item.find({ status: 'pending' }).populate('owner','name email');
  res.json(items);
});

router.put('/items/:id', auth, admin, async (req, res) => {
  const item = await Item.findById(req.params.id);
  if (!item) return res.status(404).json({ message: 'Not found' });
  item.status = req.body.status === 'rejected' ? 'rejected' : 'approved';
  await item.save();
  res.json(item);
});

module.exports = router;
