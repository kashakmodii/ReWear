const express = require("express");
const { 
  registerUser, 
  loginUser, 
  getUserProfile, 
  updateUserProfile,
  addToWishlist,
  removeFromWishlist,
  addToCart,
  updateCartQuantity,
  removeFromCart
} = require("../controllers/authController");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// Public routes
router.post("/register", registerUser);
router.post("/login", loginUser);

// Protected routes
router.get("/profile", authMiddleware, getUserProfile);
router.put("/profile", authMiddleware, updateUserProfile);

// Wishlist routes
router.post("/wishlist", authMiddleware, addToWishlist);
router.delete("/wishlist/:productId", authMiddleware, removeFromWishlist);

// Cart routes
router.post("/cart", authMiddleware, addToCart);
router.put("/cart/:productId", authMiddleware, updateCartQuantity);
router.delete("/cart/:productId", authMiddleware, removeFromCart);

module.exports = router;
