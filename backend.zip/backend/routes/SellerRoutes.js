import express from 'express';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import Seller from '../models/Seller.js';
import Product from '../models/Product.js';
import Order from '../models/Order.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../uploads/products'));
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'), false);
    }
  }
});

// Middleware to verify seller token
const verifySellerToken = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'mysecretkey');
    const seller = await Seller.findById(decoded.id);
    
    if (!seller) {
      return res.status(401).json({ message: 'Invalid token' });
    }

    req.sellerId = seller._id;
    req.seller = seller;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Invalid token' });
  }
};

// Seller Registration
router.post('/register', async (req, res) => {
  try {
    console.log('Seller registration request received:', req.body);
    const { name, email, mobile, gstin, category = "all", password } = req.body;
    
    console.log('Extracted fields:', { name, email, mobile, gstin, category, password });
    
    if (!name || !email || !mobile || !password) {
      console.log('Missing required fields:', { 
        hasName: !!name, 
        hasEmail: !!email, 
        hasMobile: !!mobile, 
        hasPassword: !!password 
      });
      return res.status(400).json({ message: "Name, email, mobile, and password are required" });
    }

    // Convert string name to object
    let nameObj;
    if (typeof name === "string") {
      const parts = name.trim().split(" ");
      nameObj = { first: parts[0], last: parts.slice(1).join(" ") || "" };
    } else if (typeof name === "object" && name.first) {
      nameObj = name;
    } else {
      return res.status(400).json({ message: "Invalid name format" });
    }

    const existingSeller = await Seller.findOne({ email });
    if (existingSeller) {
      return res.status(400).json({ message: "Seller already exists" });
    }

    const newSeller = new Seller({ 
      name: nameObj, 
      email, 
      mobile, 
      gstin, 
      category, 
      password: password  // Let the model's pre-save hook handle hashing
    });
    
    await newSeller.save();

    const token = jwt.sign({ id: newSeller._id }, process.env.JWT_SECRET || 'mysecretkey', { expiresIn: "7d" });

    res.status(201).json({
      success: true,
      message: "Seller registered successfully",
      token,
      seller: {
        id: newSeller._id,
        name: newSeller.name,
        email: newSeller.email,
        mobile: newSeller.mobile,
        gstin: newSeller.gstin,
        category: newSeller.category
      }
    });
  } catch (err) {
    console.error("Seller Registration Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Seller Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" });
    }

    const seller = await Seller.findOne({ email });
    if (!seller) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const isMatch = await seller.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ id: seller._id }, process.env.JWT_SECRET || 'mysecretkey', { expiresIn: "7d" });

    res.json({
      success: true,
      message: "Login successful",
      token,
      seller: {
        id: seller._id,
        name: seller.name,
        email: seller.email,
        mobile: seller.mobile,
        gstin: seller.gstin,
        category: seller.category
      }
    });
  } catch (err) {
    console.error("Seller Login Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Get Seller Profile
router.get('/profile', verifySellerToken, async (req, res) => {
  try {
    res.json({
      success: true,
      seller: req.seller
    });
  } catch (err) {
    console.error("Get Profile Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Add Product
router.post('/products', verifySellerToken, upload.array('images', 5), async (req, res) => {
  try {
    const {
      title,
      description,
      category,
      subcategory,
      price,
      originalPrice,
      discount,
      size,
      color,
      condition,
      material,
      gender,
      stock,
      primaryImageIndex
    } = req.body;

    if (!title || !description || !category || !subcategory || !price || !size || !color || !condition) {
      return res.status(400).json({ message: "Required fields are missing" });
    }

    // Process uploaded images
    const images = [];
    if (req.files && req.files.length > 0) {
      req.files.forEach((file, index) => {
        images.push({
          url: `/uploads/products/${file.filename}`,
          isPrimary: index === parseInt(primaryImageIndex) || (index === 0 && !primaryImageIndex)
        });
      });
    }

    const newProduct = new Product({
      sellerId: req.sellerId,
      title,
      description,
      category,
      subcategory,
      price: parseFloat(price),
      originalPrice: originalPrice ? parseFloat(originalPrice) : parseFloat(price),
      discount: discount ? parseFloat(discount) : 0,
      size,
      color,
      condition,
      material,
      gender,
      images,
      stock: parseInt(stock) || 1
    });

    await newProduct.save();

    res.status(201).json({
      success: true,
      message: "Product added successfully",
      product: newProduct
    });
  } catch (err) {
    console.error("Add Product Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Get Seller's Products
router.get('/products', verifySellerToken, async (req, res) => {
  try {
    const products = await Product.find({ sellerId: req.sellerId }).sort({ createdAt: -1 });
    
    res.json({
      success: true,
      products
    });
  } catch (err) {
    console.error("Get Products Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Update Product
router.put('/products/:id', verifySellerToken, async (req, res) => {
  try {
    const productId = req.params.id;
    const updateData = req.body;

    const product = await Product.findOne({ _id: productId, sellerId: req.sellerId });
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    const updatedProduct = await Product.findByIdAndUpdate(
      productId,
      updateData,
      { new: true }
    );

    res.json({
      success: true,
      message: "Product updated successfully",
      product: updatedProduct
    });
  } catch (err) {
    console.error("Update Product Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Delete Product
router.delete('/products/:id', verifySellerToken, async (req, res) => {
  try {
    const productId = req.params.id;

    const product = await Product.findOne({ _id: productId, sellerId: req.sellerId });
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    await Product.findByIdAndDelete(productId);

    res.json({
      success: true,
      message: "Product deleted successfully"
    });
  } catch (err) {
    console.error("Delete Product Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Get Seller's Orders
router.get('/orders', verifySellerToken, async (req, res) => {
  try {
    const orders = await Order.find({ sellerId: req.sellerId })
      .populate('userId', 'name email')
      .populate('items.productId', 'title images')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      orders
    });
  } catch (err) {
    console.error("Get Orders Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Update Order Status
router.put('/orders/:id/status', verifySellerToken, async (req, res) => {
  try {
    const orderId = req.params.id;
    const { status } = req.body;

    if (!['pending', 'confirmed', 'cancelled'].includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }

    const order = await Order.findOne({ _id: orderId, sellerId: req.sellerId });
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    order.status = status;
    await order.save();

    res.json({
      success: true,
      message: "Order status updated successfully",
      order
    });
  } catch (err) {
    console.error("Update Order Status Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Get Dashboard Stats
router.get('/dashboard', verifySellerToken, async (req, res) => {
  try {
    const totalProducts = await Product.countDocuments({ sellerId: req.sellerId });
    const activeProducts = await Product.countDocuments({ sellerId: req.sellerId, status: 'active' });
    const totalOrders = await Order.countDocuments({ sellerId: req.sellerId });
    const pendingOrders = await Order.countDocuments({ sellerId: req.sellerId, status: 'pending' });
    
    const totalRevenue = await Order.aggregate([
      { $match: { sellerId: req.sellerId, status: 'confirmed' } },
      { $group: { _id: null, total: { $sum: '$totalAmount' } } }
    ]);

    res.json({
      success: true,
      stats: {
        totalProducts,
        activeProducts,
        totalOrders,
        pendingOrders,
        totalRevenue: totalRevenue[0]?.total || 0
      }
    });
  } catch (err) {
    console.error("Get Dashboard Stats Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

export default router;