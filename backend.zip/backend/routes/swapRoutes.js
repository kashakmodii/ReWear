// backend/routes/swapRoutes.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const swapCtrl = require('../controllers/swapController');

router.post('/request', auth, swapCtrl.requestSwap);
router.put('/accept/:id', auth, swapCtrl.acceptSwap); // id = orderId
router.put('/complete/:id', auth, swapCtrl.completeSwap);

module.exports = router;
