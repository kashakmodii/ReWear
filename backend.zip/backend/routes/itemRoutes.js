// backend/routes/itemRoutes.js
const express = require('express');
const router = express.Router();
const upload = require('../middleware/uploadMiddleware');
const auth = require('../middleware/authMiddleware');
const itemCtrl = require('../controllers/itemController');

router.get('/', itemCtrl.getApprovedItems);
router.get('/:id', itemCtrl.getItem);
router.post('/', auth, upload.array('images', 6), itemCtrl.addItem);
router.delete('/:id', auth, itemCtrl.deleteItem);

module.exports = router;
