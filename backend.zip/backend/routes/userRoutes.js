import express from 'express';
import mongoose from 'mongoose';
import Product from '../models/Product.js';
import Order from '../models/Order.js';

const router = express.Router();


// Middleware to verify user token
const verifyUserToken = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    const jwt = require('jsonwebtoken');
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'mysecretkey');
    
    const User = mongoose.model("users");
    const user = await User.findById(decoded.id);
    
    if (!user) {
      return res.status(401).json({ message: 'Invalid token' });
    }

    req.userId = user._id;
    req.user = user;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Invalid token' });
  }
};

// Get all products (for user side)
router.get('/products', async (req, res) => {
  try {
    const { category, search, page = 1, limit = 12 } = req.query;
    const query = { status: 'active' };

    if (category && category !== 'all') {
      query.category = category;
    }

    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }

    const products = await Product.find(query)
      .populate('sellerId', 'name email')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Product.countDocuments(query);

    res.json({
      success: true,
      products,
      pagination: {
        current: parseInt(page),
        pages: Math.ceil(total / limit),
        total
      }
    });
  } catch (err) {
    console.error("Get Products Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Get single product
router.get('/products/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id)
      .populate('sellerId', 'name email mobile');

    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    res.json({
      success: true,
      product
    });
  } catch (err) {
    console.error("Get Product Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Get products by category
router.get('/products/category/:category', async (req, res) => {
  try {
    const { category } = req.params;
    const { page = 1, limit = 12 } = req.query;

    const products = await Product.find({ 
      category, 
      status: 'active' 
    })
      .populate('sellerId', 'name email')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Product.countDocuments({ category, status: 'active' });

    res.json({
      success: true,
      products,
      pagination: {
        current: parseInt(page),
        pages: Math.ceil(total / limit),
        total
      }
    });
  } catch (err) {
    console.error("Get Products by Category Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Place order
router.post('/orders', verifyUserToken, async (req, res) => {
  try {
    const { items, shippingAddress } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ message: "Items are required" });
    }

    if (!shippingAddress || !shippingAddress.name || !shippingAddress.address) {
      return res.status(400).json({ message: "Shipping address is required" });
    }

    let totalAmount = 0;
    const orderItems = [];

    // Validate products and calculate total
    for (const item of items) {
      const product = await Product.findById(item.productId);
      if (!product) {
        return res.status(400).json({ message: `Product ${item.productId} not found` });
      }

      if (product.stock < item.quantity) {
        return res.status(400).json({ message: `Insufficient stock for ${product.title}` });
      }

      // Calculate price with discount
      const discount = product.discount || 0;
      const finalPrice = discount > 0 
        ? product.price - (product.price * discount / 100) 
        : product.price;
      const itemTotal = finalPrice * item.quantity;
      totalAmount += itemTotal;

      orderItems.push({
        productId: product._id,
        quantity: item.quantity,
        price: finalPrice
      });
    }

    // Generate order ID
    const orderId = `RW${Date.now()}${Math.random().toString(36).substr(2, 4).toUpperCase()}`;

    // Create order
    const newOrder = new Order({
      orderId,
      userId: req.userId,
      sellerId: items[0].sellerId, // Assuming all items from same seller for simplicity
      items: orderItems,
      totalAmount,
      shippingAddress
    });

    await newOrder.save();

    // Update product stock
    for (const item of orderItems) {
      await Product.findByIdAndUpdate(item.productId, {
        $inc: { stock: -item.quantity }
      });
    }

    res.status(201).json({
      success: true,
      message: "Order placed successfully",
      order: newOrder
    });
  } catch (err) {
    console.error("Place Order Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Get user's orders
router.get('/orders', verifyUserToken, async (req, res) => {
  try {
    const orders = await Order.find({ userId: req.userId })
      .populate('sellerId', 'name email')
      .populate('items.productId', 'title images')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      orders
    });
  } catch (err) {
    console.error("Get User Orders Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

// Get categories
router.get('/categories', async (req, res) => {
  try {
    const categories = [
      { id: 'clothing', name: 'Clothing', subcategories: ['Tops', 'Bottoms', 'Dresses', 'Outerwear', 'Activewear'] },
      { id: 'footwear', name: 'Footwear', subcategories: ['Sneakers', 'Boots', 'Sandals', 'Heels', 'Flats'] },
      { id: 'bags', name: 'Bags & Purses', subcategories: ['Handbags', 'Backpacks', 'Clutches', 'Totes', 'Crossbody'] },
      { id: 'jewelry', name: 'Jewelry', subcategories: ['Necklaces', 'Earrings', 'Rings', 'Bracelets', 'Watches'] },
      { id: 'accessories', name: 'Accessories', subcategories: ['Belts', 'Scarves', 'Hats', 'Sunglasses', 'Wallets'] },
      { id: 'watches', name: 'Watches', subcategories: ['Analog', 'Digital', 'Smart', 'Sports', 'Luxury'] },
      { id: 'eyewear', name: 'Eyewear', subcategories: ['Sunglasses', 'Prescription', 'Reading', 'Sports', 'Fashion'] }
    ];

    res.json({
      success: true,
      categories
    });
  } catch (err) {
    console.error("Get Categories Error:", err);
    res.status(500).json({ message: err.message || "Server error" });
  }
});

export default router;